package com.example.registrationformapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

class MainActivity : AppCompatActivity() {

    private lateinit var binding : MainActivityBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        setupSpinner()
        setupButton()
    }

    private fun setupButton() {
    }

    private fun setupSpinner() {
    }

    private fun createAccount(){

    }
}